var diff = require('./lib.js').diff,
	test_battery = require('./test_battery.js').test_battery;

var start = function() {
	console.log('TESTS STARTED\n');
	var res = [];

	test_battery.forEach(function(test, index) {
		var expected_res = test['res'];
		var result = diff(test['obj_1'], test['obj_2']);

		if(JSON.stringify(expected_res) == JSON.stringify(result)) {
			console.log('Test '+index+' OK!');
		} else {
			console.log('Test '+index+' NOT OK!');
			console.log('--expected result--');
			console.log(expected_res);
			console.log('--actual result--');
			console.log(result);
		}
	});

}

start();