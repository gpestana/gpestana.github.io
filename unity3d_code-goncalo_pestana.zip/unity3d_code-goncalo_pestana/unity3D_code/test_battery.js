var json_1 = {
  "foo": {
    "bar": "baz",
    "biz": "foo"
  },
  "fiz": {
    "foo": "baz"
  },
  "bar": "baz",
  "baz": [
    "foo",
    "bar"
  ],
  "miss": 123
}

var json_2 = {
  "foo": {
    "bar": "baz1",
    "biz": "foo"
  },
  "fiz": {
    "foo": "baz"
  },
  "bar": "baz",
  "baz": [
    "foo1"
  ],
  "new_value": 1
}

var res = {
  "foo": {
    "bar": "baz1"
  },
  "baz": [
    "foo1"
  ],
  "miss": undefined,
  "new_value": 1
}



module.exports.test_battery = [
  { 
    obj_1: json_1,
    obj_2: json_2,
    res: res
  }
  //......
];
