var fs = require('fs'),
	diff = require('./lib.js').diff;


var init = function() {
	var json_1 = JSON.parse(fs.readFileSync(process.argv[2], 'UTF-8'));
	var json_2 = JSON.parse(fs.readFileSync(process.argv[3], 'UTF-8'));

	console.log(diff(json_1, json_2));
}


init();
