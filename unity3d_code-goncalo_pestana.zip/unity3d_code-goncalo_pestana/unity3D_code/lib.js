var diff = function(json_1, json_2) {
	var diff_json = {};

	for (key in json_1) {
		if(JSON.stringify(json_1[key]) !== JSON.stringify(json_2[key])) {
			inspect(json_1[key], json_2[key], key, diff_json);
		}
		
		delete json_2[key];
	}
	//add new elements
	for (key in json_2) {
		diff_json[key] = json_2[key];
	}

	return diff_json;
}

var inspect = function(obj_1, obj_2, key, diff_json) {
	var diff_obj;

	if(obj_1.constructor == Array) {
		diff_obj = [];
		for(el_2 in obj_2) {
			if (obj_1.indexOf(el_2) == -1) {
				diff_obj.push(obj_2[el_2]);
			}
		}

	} else if (obj_1.constructor == Object) {
		diff_obj = {};
		for (k in obj_2) {
			if(obj_2[k] !== obj_1[k]) {
				diff_obj[k] = obj_2[k];
			}
		}

		diff_json[key] = diff_obj;

	} else {
		diff_obj = obj_2;
	}

	//add new object to diff_json with key
	diff_json[key] = diff_obj;
}



module.exports.diff = diff